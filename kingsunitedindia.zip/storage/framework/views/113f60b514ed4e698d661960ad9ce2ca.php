<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kings United</title>
    <?php echo $__env->make('partial.links.headLinks', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldPushContent('style'); ?>
</head>

<body class="body-bg-color-1">
    <div class="page-wrapper">
        <?php echo $__env->make('partial.componants.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('partial.componants.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('partial.links.scriptLink', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\kingsunitedindia\resources\views/layout/app.blade.php ENDPATH**/ ?>