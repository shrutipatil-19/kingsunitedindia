<script src="<?php echo e(asset('assets/vendors/jquery/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/jarallax/jarallax.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/jquery-ajaxchimp/jquery.ajaxchimp.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/jquery-appear/jquery.appear.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/jquery-magnific-popup/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/jquery-validate/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/odometer/odometer.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/swiper/swiper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/wnumb/wNumb.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/wow/wow.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/isotope/isotope.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/owl-carousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/bootstrap-select/js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/jquery-ui/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/nice-select/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/countdown/countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/marque/marquee.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendors/sidebar-content/jquery-sidebar-content.js')); ?>"></script>

<!-- template js -->
<script src="<?php echo e(asset('assets/js/eventflow.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\kingsunitedindia\resources\views/partial/links/scriptLink.blade.php ENDPATH**/ ?>